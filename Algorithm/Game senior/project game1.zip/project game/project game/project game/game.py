#===import===
import tkinter as tk
from tkinter import *
import winsound
from PIL import Image, ImageTk
import random
from random import randrange,choice


#===Constan===
vertical_velocity = 0

WIN_WIDTH =1400
WIN_HEIGHT = 740
SPEED = 10

root = tk.Tk()
root.geometry(str(WIN_WIDTH)+"x"+str(WIN_HEIGHT))
root.title('Mario Jumper')
canvas = tk.Canvas(root, scrollregion= (0,0,4000,5000)) 
frame = tk.Frame()

#====Variable===
game_page1 = tk.PhotoImage(file="img/page1.png")
game_lower = tk.PhotoImage(file="img/lower.png")

btn_introductio = tk.PhotoImage(file="img/btn_introduction.png")
btn_level = tk.PhotoImage(file="img/btn_level.png")
btn_play = tk.PhotoImage(file="img/btn_play.png")
btn_choose=tk.PhotoImage(file="img/btn_choose.png")
btn_lower= tk.PhotoImage(file="img/btn_lower.png")
btn_high= tk.PhotoImage(file="img/btn_high.png")
btn_meduim= tk.PhotoImage(file="img/btn_medium.png")



pic_mario = tk.PhotoImage(file="img/mario.png")
pic_giant = tk.PhotoImage(file="img/diamond.png")
pic_goomba = tk.PhotoImage(file="img/heart.png")
pic_introduction = tk.PhotoImage(file="img/introduction.png")
pic_level= tk.PhotoImage(file="img/level.png")
background_lower= tk.PhotoImage(file="img/lower.png")
background_high= tk.PhotoImage(file="img/high.png")
background_medium= tk.PhotoImage(file="img/medium.png")

diamond= tk.PhotoImage(file="img/diamond.png")
goomba= tk.PhotoImage(file="img/goomba.png")
giant_stick= tk.PhotoImage(file="img/Giant Stick.png")
heart= tk.PhotoImage(file="img/heart.png")

btn_back = tk.PhotoImage(file="img/btn_back.png")

player_X = 150
player_Y = 450
enamyX = 1400
listOfDiedVirus = []
listOfBullet = []
listOfLives = []
listOfVirus = []
listOfCash = []
diamonds=[]
keyPressed = []
listOfDm = []



isStart = True
isMario= 1
marioMeetenemy = 0
isGoomba =0
isGiantstick=0
level1 = 0
level2 =0
marioCanLive=0
killVirus = 0
toConfig = 0
totalCash = 0
count_create_dm = 0
enamy_x = 450
enamy_x = 1350

score = 0
#===Function===
 
def gameShow(event):
    canvas.delete("all")
    canvas.create_image(680, 372, image=game_page1)
    canvas.create_image(870,280, image=btn_introductio, tags="introduction")
    canvas.create_image(870,410,image=btn_level, tags="level")
    canvas.create_image(870,520 ,image=btn_play, tags ="play")
    # winsound.PlaySound("sound/game-show.wav", winsound.SND_ASYNC)


#===introduction===
def gameIntroduction(event):
    canvas.delete("all")
    canvas.create_image(680, 372, image=pic_introduction)
    canvas.create_image(120, 50, image=btn_back, tags="back")

    
#===lavel===
def gameLevel(event):
    canvas.delete("all")
    canvas.create_image(680, 372, image=pic_level)
    canvas.create_image(700,150, image=btn_choose, tags="choose")
    canvas.create_image(300,300, image=btn_lower, tags="lower")
    canvas.create_image(700,300, image=btn_high, tags="high")
    canvas.create_image(1100,300, image=btn_meduim, tags="medium")
    canvas.create_image(120, 50, image=btn_back, tags="back")


#================================back ================================

#================================ Lower Level ================================


   
def lowerLevel(event):
    global player
    canvas.delete("all")
    background_image_label_1= canvas.create_image(0, 0,anchor=tk.NW, image=background_lower)
    background_image_label_2= canvas.create_image(1400, 0,anchor=tk.NW, image=background_lower)
    canvas.create_image(120, 50, image=btn_back, tags="back")

    def scroll_bg_image():
        
        canvas.move(background_image_label_1, -1, 0)
        canvas.move(background_image_label_2, -1, 0)

        if canvas.coords(background_image_label_1)[0]<-1400:
            canvas.coords(background_image_label_1, 1400, 0)
        elif canvas.coords(background_image_label_2)[0]<-1400:
            canvas.coords(background_image_label_2, 1400, 0)
        canvas.after(10, scroll_bg_image)
   
    scroll_bg_image()
    
#==============================player=========================
    player = canvas.create_image(100, 500, image=pic_mario)
    creat_dm()
    creat_enamy()

#  =============== store daimond ==========================================================


    # diamond_count_label = tk.Label(root, text="Diamonds: 0", font=("Arial", 16))
    # diamond_count_label.place(x=WIN_WIDTH - 180, y=10)

# ====================> Create Diamond<====================== 
def creat_dm():
    global count_create_dm, enamy_x
    count_create_dm += 1
    enamy_y = randrange(500,655)
    speed_create = randrange(3000,6000)
    enamy =canvas.create_image(enamy_x,enamy_y, image=diamond )
    move_dm(enamy)
    if isStart and count_create_dm < 50:
        canvas.after(speed_create, lambda:creat_dm())


# ====================> Move Diamond <========================
def delete_item(item):
    canvas.delete(item)

def move_dm(dm):
    global totaldm,listOfLives, canLive, toConfig
    canvas.move(dm, -5, 0)
    listOfDm.append(dm)
    positiondm = canvas.coords(dm)
    positionPlayer = canvas.coords(player)
    if len(positiondm) > 0:
        if (positionPlayer[0] +20 >= positiondm[0] and positionPlayer[0]-20 <= positiondm[0]) and (positionPlayer[1]-20 <= positiondm[1]+20 and positionPlayer[1]+40 >=  positiondm[1]-20):
            delete_item(dm)
        if (positionPlayer[0] +20 >= positiondm[0] and positionPlayer[0]-20 <= positiondm[0]) and (positionPlayer[1]-20 <= positiondm[1]+20 and positionPlayer[1]+40 >=  positiondm[1]-20):
            delete_item(dm)
            toConfig -= 1
        elif positiondm[0] < 0:
            delete_item(dm)
    
    canvas.after(50, lambda:move_dm(dm))

# ====================> Create enamy<====================== 
def creat_enamy():
    global count_create_dm, enamy_x
    count_create_dm += 1
    enamy_y = randrange(500,655)
    speed_create = randrange(3000,6000)
    enamy =canvas.create_image(enamy_x,enamy_y, image=giant_stick )
    move_dm(enamy)
    if isStart and count_create_dm < 50:
        canvas.after(speed_create, lambda:creat_enamy())



#================move Plaer==================================
def move(event):
    global diamonds
    if event.keysym == "Left" and canvas.coords(player)[0] > 0:
        canvas.move(player, -10, 0)  # Move left (-10 in the x-axis)
    elif event.keysym == "Right" and canvas.coords(player)[0] < canvas.winfo_width():
        canvas.move(player, 10, 0)  # Move right (10 in the x-axis)
    elif event.keysym == "Down" and canvas.coords(player)[1] < canvas.winfo_height():
        canvas.move(player, 0, 10)  # Move down (10 in the y-axis)
    elif event.keysym == "Up" and canvas.coords(player)[1] > 0:
        canvas.move(player, 0, -10)  # Move up (-10 in the y-axis)
    
    player_coords = canvas.coords(player)
    for diamond in diamonds:
        diamond_coords = canvas.coords(diamond)
        if player_coords[0] == diamond_coords[0] and player_coords[1] == diamond_coords[1]:
            canvas.delete(diamond)  # Remove the picked up diamond from the canvas
            diamonds.remove(diamond)  # Remove the picked up diamond from the list
            print("Picked up a diamond!")
    
    print(canvas.coords(player))

root.bind("<Key>", move)



#================================ High Level ================================
def highLevel(event):
    global player
    canvas.delete("all")
    background_image_label_1= canvas.create_image(0, 0,anchor=tk.NW, image=background_high)
    background_image_label_2= canvas.create_image(1400, 0,anchor=tk.NW, image=background_high)

    def scroll_bg_image():
        
        canvas.move(background_image_label_1, -1, 0)
        canvas.move(background_image_label_2, -1, 0)

        if canvas.coords(background_image_label_1)[0]<-1400:
            canvas.coords(background_image_label_1, 1400, 0)
        elif canvas.coords(background_image_label_2)[0]<-1400:
            canvas.coords(background_image_label_2, 1400, 0)
        canvas.after(10, scroll_bg_image)
   
    scroll_bg_image()
#=====================player====================
    player = canvas.create_image(100, 500, image=pic_mario)
    creat_dm()

#================================ Medium Level ================================
def mediumLevel(event):
    global player
    canvas.delete("all")
    background_image_label_1= canvas.create_image(0, 0,anchor=tk.NW, image=background_medium)
    background_image_label_2= canvas.create_image(1400, 0,anchor=tk.NW, image=background_medium)

    def scroll_bg_image():
        
        canvas.move(background_image_label_1, -1, 0)
        canvas.move(background_image_label_2, -1, 0)

        if canvas.coords(background_image_label_1)[0]<-1400:
            canvas.coords(background_image_label_1, 1400, 0)
        elif canvas.coords(background_image_label_2)[0]<-1400:
            canvas.coords(background_image_label_2, 1400, 0)
        canvas.after(10, scroll_bg_image)
   
    scroll_bg_image()
#=====================player====================
    player = canvas.create_image(100, 500, image=pic_mario) 
    creat_dm()

    

#===create game show ===

canvas.create_image(680, 372, image=game_page1)
canvas.create_image(870,280, image=btn_introductio, tags="introduction")
canvas.create_image(870,410,image=btn_level, tags="level")
canvas.create_image(870,520 ,image=btn_play, tags ="play")
canvas.tag_bind("introduction","<Button-1>", gameIntroduction)
canvas.tag_bind("back","<Button-1>",gameShow)
canvas.tag_bind("level","<Button-1>",gameLevel)
canvas.tag_bind("lower","<Button-1>",lowerLevel)
canvas.tag_bind("high","<Button-1>",highLevel)
canvas.tag_bind("medium","<Button-1>",mediumLevel)
canvas.tag_bind("play","<Button-1>",lowerLevel)



#===Main roo===
canvas.pack(expand=True, fill='both')

root.mainloop()