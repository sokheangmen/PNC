
arrayDic=[
 {'name': 'Nit', 'subject': 'Algorithm', 'score': 10},
 {'name': 'Visal', 'subject': 'PL', 'score': 80},
 {'name': 'Dyna', 'subject': 'Algorithm', 'score': 49},
 {'name': 'Virak','subject': 'English', 'score': 50},
 {'name': 'Sreymom', 'subject': 'Algorithm', 'score': 50},
 {'name': 'Khid', 'subject': 'Algorithm', 'score': 40},
]
countName=""
for i in arrayDic:
    if i['score']<50:
        countName=(i["name"])
print(str(len(i["name"]))+" "+("students failed algorithm ")+i["name"])