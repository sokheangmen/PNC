arrayOfString=["Lexiaa","Bophaa"]
result=[]
sum=0
for arr in arrayOfString:
    for j in arr:
        if j=="a":
           sum+=1
    if sum==2:
        result.append(arr)
print(result)