def reverseText(text):
    getReuslt=""
    data=[]
    for arr in text:
        getReuslt+=(arr[::-1])
        data.append(getReuslt)
        getReuslt=""
    return data
text=eval(input("Enter array Of string : "))
reverseArray=reverseText(text)
print(reverseArray[::-1])
