arrayDic1=[
 {"subject": "html", "class": "WEP-B", "teacher-id": 45},
 {"subject": "html", "class": "WEP-A", "teacher-id": 36},
 {"subject": "algorithm", "class": "WEP-B", "teacher-id": 36},
]
arrayDic2=[
 {"teacher-id": "36", "first-name": "rady", "last-name": "Y"},
 {"teacher-id": "45", "first-name": "ronan", "last-name": "the best"},
]
getId=""
getsubject=""
for dic in arrayDic1:
    for key in arrayDic2:
        getsubject=dic["subject"]
        getId=key["teacher-id"]
    if getId == key["teacher-id"]:
        print(key["last-name"])