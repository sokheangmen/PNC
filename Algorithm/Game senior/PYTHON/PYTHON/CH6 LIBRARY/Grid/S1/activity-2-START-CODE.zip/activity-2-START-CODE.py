import tkinter as tk


grid = [0,0,1,0,0,0,0]

def getIndexOne(arr):
    # TODO
    return None


def moveRight(event):
    global grid
    # TODO 

def moveLeft(event):
    global grid
    # TODO 


SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600

root = tk.Tk()
root.geometry(str(SCREEN_WIDTH)+"x"+str(SCREEN_HEIGHT))
frame = tk.Frame()
frame.master.title("PNC Data structure to graphism")
frame.pack(expand=True, fill='both')
canvas = tk.Canvas(frame)
canvas.pack(expand=True, fill="both")

root.bind("<r>", moveRight)
root.bind("<l>", moveLeft)

root.mainloop()
