
# 1 - Enter a number
number = int( input('Enter a number: ') )
message = ""
if number >= 10 and number <= 20:
   message = "inside"
else:
    message = "outside"
print(message)
