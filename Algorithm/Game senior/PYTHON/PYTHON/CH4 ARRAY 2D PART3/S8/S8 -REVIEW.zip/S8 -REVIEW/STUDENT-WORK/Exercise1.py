# case 1 :
Array2D=eval(input())
newArray=[]
for row in range(len(Array2D[0])):
    result=0
    for col in range(len(Array2D)):
        result+=Array2D[col][row]
    newArray.append(result)
print(newArray)
